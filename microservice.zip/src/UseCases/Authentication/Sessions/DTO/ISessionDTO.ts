export interface ISessionUserDTO {
  idUser: string;
}
