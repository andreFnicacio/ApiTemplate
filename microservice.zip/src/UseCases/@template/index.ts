import { container } from 'tsyringe';

import { ReplaceController } from './Replace.Controller';
import { ReplaceUseCase } from './Replace.UseCase';

export const ReplaceControllerIndex = new ReplaceController(container.resolve(ReplaceUseCase));
