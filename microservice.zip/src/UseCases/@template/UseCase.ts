import { inject, injectable } from 'tsyringe';

import { ZODVerifyParse } from '@shared/Util/ZOD/zod';

import { IReplaceDTO } from './DTO/IReplaceDTO';
import { SchemaReplace } from './SchemaReplace';

@injectable()
export class ReplaceUseCase {
  constructor(@inject('Repository') private Repository: IRepository) {}

  async execute(request: IReplaceDTO.Params) {
    const {} = ZODVerifyParse({
      schema: SchemaReplace,
      data: request,
    });

    const returnResponse = {};

    return returnResponse;
  }
}
