import { z } from 'zod';

import { SchemaReplace } from '../SchemaReplace';

export type SchemaReplaceZod = z.output<typeof SchemaReplace>;

export namespace IReplaceDTO {
  export type Params = SchemaReplaceZod;

  export type Result = {};
}
