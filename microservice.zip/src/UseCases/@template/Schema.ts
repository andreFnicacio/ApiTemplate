import { z } from 'zod';

export const SchemaReplace = z.object({});
