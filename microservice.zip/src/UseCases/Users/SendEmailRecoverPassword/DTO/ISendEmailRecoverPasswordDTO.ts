export namespace ISendEmailRecoverPasswordDTO {
  export type Params = {
    email: string;
  };

  export type Result = {
    message: string;
  };
}
